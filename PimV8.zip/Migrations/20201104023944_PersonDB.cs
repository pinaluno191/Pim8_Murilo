﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace PimV8.Migrations
{
    public partial class PersonDB : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
